#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include"Service/service.h"
#include"Database/database.h"
#include <QMainWindow>
#include"selectuser.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_ManageUser_clicked();
    void start_stop();

private:
    Ui::MainWindow *ui;
    SelectUser *selectuser;
    bool checked ;
};
#endif // MAINWINDOW_H
