#include "add_edituser.h"
#include "ui_add_edituser.h"

Add_EditUser::Add_EditUser(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Add_EditUser)
{
    ui->setupUi(this);
    connect(ui->radioButton, &QRadioButton::clicked, this, &Add_EditUser::updateWidget);
    connect(ui->radioButton_2, &QRadioButton::clicked, this, &Add_EditUser::updateWidget);
}
void Add_EditUser::updateWidget(){
    if(ui->radioButton_2->isChecked()){
        ui->stackedWidget->setCurrentWidget(ui->add_user);
    }
    else if(ui->radioButton->isChecked()){
        ui->stackedWidget->setCurrentWidget(ui->edit_user);
    }
}

Add_EditUser::~Add_EditUser()
{
    delete ui;
}
