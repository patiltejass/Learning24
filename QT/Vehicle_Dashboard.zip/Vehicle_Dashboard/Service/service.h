#ifndef SERVICE_H
#define SERVICE_H

#include <QObject>
#include"D:\DELTA\GIthub\Learning24\QT\Vehicle_Dashboard\Database\database.h"


class Service:public QObject
{
    Q_OBJECT
public:
    Service();
    database *dbptr;
    // bool updateTotalDistanceTravelled(int distance);
    // bool updateBatteryLevel(int level);
    // bool updateEngineHours(int hours);
    // bool updateEstimatedFuelRange(int range);

    // int getTotalDistanceTravelled();
    // int getBatteryLevel();
    // int getEngineHours();
    // int getEstimatedFuelRange();
};

#endif // SERVICE_H
