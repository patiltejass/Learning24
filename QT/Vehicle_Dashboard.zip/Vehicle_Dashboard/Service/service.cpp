#include "service.h"

Service::Service():dbptr(database::objectprovider()){}

// bool Service::updateTotalDistanceTravelled(int distance) {
//     return dbptr.updateTotalDistanceTravelled(distance);
// }

// bool Service::updateBatteryLevel(int level) {
//     return dbptr.updateBatteryLevel(level);
// }

// bool Service::updateEngineHours(int hours) {
//     return dbptr.updateEngineHours(hours);
// }

// bool Service::updateEstimatedFuelRange(int range) {
//     return dbptr.updateEstimatedFuelRange(range);
// }

// int Service::getTotalDistanceTravelled() {
//     return dbptr.getTotalDistanceTravelled();
// }

// int Service::getBatteryLevel() {
//     return dbptr.getBatteryLevel();
// }

// int Service::getEngineHours() {
//     return dbptr.getEngineHours();
// }

// int Service::getEstimatedFuelRange() {
//     return dbptr.getEstimatedFuelRange();
// }
