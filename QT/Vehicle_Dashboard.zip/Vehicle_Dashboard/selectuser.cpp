#include "selectuser.h"
#include "ui_selectuser.h"

SelectUser::SelectUser(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SelectUser)
{
    ui->setupUi(this);
}

SelectUser::~SelectUser()
{
    delete addedit;
    delete ui;
}

void SelectUser::on_AddUserButton_clicked()
{
    addedit = new Add_EditUser();
    addedit->show();
}

