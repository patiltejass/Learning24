#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , checked(false)
{
    ui->setupUi(this);

    database db;

connect(ui->StartStopButton, &QPushButton::clicked, this, &MainWindow::start_stop);
}

void MainWindow::start_stop() {
    checked = !checked;  // Toggle the state

    if (checked) {
        // Start actions
        ui->StartStopButton->setText("Stop"); // Example state change
        ui->StartStopButton->setStyleSheet(
            "background-color: rgb(107, 174, 255);"
            "border-radius: 62px;"
            "text-align: center;"
            "color: rgb(255, 255, 255);"
            ); // ...
    } else {
        // Stop actions
        ui->StartStopButton->setText("Start"); // Example state change
        ui->StartStopButton->setStyleSheet("background-color: rgb(45, 45, 45);"
                                           "border-radius: 62px;"
                                           "text-align: centre;"
                                           "color: rgb(255,255,255);"
                                           ); // ...
    }
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ManageUser_clicked()
{
    selectuser = new SelectUser();
    selectuser->show();
}
