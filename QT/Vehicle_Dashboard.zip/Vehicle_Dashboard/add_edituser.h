#ifndef ADD_EDITUSER_H
#define ADD_EDITUSER_H

#include <QDialog>

namespace Ui {
class Add_EditUser;
}

class Add_EditUser : public QDialog
{
    Q_OBJECT

public:
    explicit Add_EditUser(QWidget *parent = nullptr);
    ~Add_EditUser();

private slots:
        void updateWidget();

private:
    Ui::Add_EditUser *ui;
};

#endif // ADD_EDITUSER_H
