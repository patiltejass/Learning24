#include "database.h"

database::database() {
    db =QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbpath);
    if (openConnection()) {
        createTable();
    }
}

database::~database()
{
    closeConnection();
}

bool database::openConnection()
{
    if (!db.open()) {
        qDebug() << "Error: " << db.lastError().text();
        return false;
    }
    return true;
}

void database::closeConnection()
{
    db.close();
}

bool database::createTable()
{
    // Create the "user" table
    QSqlQuery query;
    if (!query.exec("CREATE TABLE IF NOT EXISTS user ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "mode TEXT, "
                    "color INT, "
                    "distance INT)"))
    {
        qDebug() << query.lastError().text();
        return false;
    }
    qDebug() << "User Table Created Successfully";

    // Create the "vehicleInfo" table with a foreign key constraint
    if (!query.exec("CREATE TABLE IF NOT EXISTS vehicleInfo ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "user_name TEXT UNIQUE, "
                    "totalKms INT, "
                    "batteryLevel INT, "
                    "engineHours INT, "
                    "FOREIGN KEY (user_name) REFERENCES user (mode))"))
    {
        qDebug() << query.lastError().text();
        return false;
    }
    qDebug() << "Vehicle Info Table Created Successfully";

    return true;
}
// bool database::updateTotalDistanceTravelled(int distance) {
//     QSqlQuery query;
//     query.prepare("UPDATE VehicleDashboard SET totalDistanceTravelled = totalDistanceTravelled + :totalDistanceTravelled");
//     query.bindValue(":totalDistanceTravelled", distance);

//     if (!query.exec()) {
//         qDebug() << "Error updating totalDistanceTravelled:" << query.lastError().text();
//         return false;
//     }

//     qDebug() << "Total distance travelled updated successfully.";
//     return true;
// }
// bool database::updateBatteryLevel(int level) {
//     QSqlQuery query;
//     query.prepare("UPDATE VehicleDashboard SET batteryLevel = batteryLevel + :batteryLevel");
//     query.bindValue(":batteryLevel", level);

//     if (!query.exec()) {
//         qDebug() << "Error updating batteryLevel:" << query.lastError().text();
//         return false;
//     }

//     qDebug() << "Battery level updated successfully.";
//     return true;
// }
// bool database::updateEngineHours(int hours) {
//     QSqlQuery query;
//     query.prepare("UPDATE VehicleDashboard SET engineHours = :engineHours");
//     query.bindValue(":engineHours", hours);

//     if (!query.exec()) {
//         qDebug() << "Error updating engineHours:" << query.lastError().text();
//         return false;
//     }

//     qDebug() << "Engine hours updated successfully.";
//     return true;
// }
// bool database::updateEstimatedFuelRange(int range) {
//     QSqlQuery query;
//     query.prepare("UPDATE VehicleDashboard SET estimatedFuelRange = :estimatedFuelRange");
//     query.bindValue(":estimatedFuelRange", range);

//     if (!query.exec()) {
//         qDebug() << "Error updating estimatedFuelRange:" << query.lastError().text();
//         return false;
//     }

//     qDebug() << "Estimated fuel range updated successfully.";
//     return true;
// }

// int database::getTotalDistanceTravelled() {
//     QSqlQuery query("SELECT totalDistanceTravelled FROM VehicleDashboard");
//     if (query.exec() && query.next()) {
//         return query.value(0).toInt();
//     } else {
//         qDebug() << "Error retrieving totalDistanceTravelled:" << query.lastError().text();
//         return 0;
//     }
// }

// int database::getBatteryLevel() {
//     QSqlQuery query("SELECT batteryLevel FROM VehicleDashboard");
//     if (query.exec() && query.next()) {
//         return query.value(0).toInt();
//     } else {
//         qDebug() << "Error retrieving batteryLevel:" << query.lastError().text();
//         return 0;
//     }
// }

// int database::getEngineHours() {
//     QSqlQuery query("SELECT engineHours FROM VehicleDashboard");
//     if (query.exec() && query.next()) {
//         return query.value(0).toInt();
//     } else {
//         qDebug() << "Error retrieving engineHours:" << query.lastError().text();
//         return 0;
//     }
// }

// int database::getEstimatedFuelRange() {
//     QSqlQuery query("SELECT estimatedFuelRange FROM VehicleDashboard");
//     if (query.exec() && query.next()) {
//         return query.value(0).toInt();
//     } else {
//         qDebug() << "Error retrieving estimatedFuelRange:" << query.lastError().text();
//         return 0;
//     }
// }
