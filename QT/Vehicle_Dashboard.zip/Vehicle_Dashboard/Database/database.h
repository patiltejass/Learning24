#ifndef DATABASE_H
#define DATABASE_H

#include <QObject>
#include<QtSql/QSqlDatabase>
#include<QtSql/QSqlQuery>
#include<QtSql/QSqlError>
#include<QDir>

class database:public QObject
{
    Q_OBJECT
public:
    database();
    database(const database&)=delete;
    database& operator =(const database&)=delete;
    QString path = QDir::currentPath();
    QString dbpath = path+"/example.db";
    QSqlDatabase db;
    static database* objectprovider(){
        database* db= new database;
        return db;
    }
    bool openConnection();
    void closeConnection();
    bool createTable();
    // bool updateTotalDistanceTravelled(int distance);
    // bool updateBatteryLevel(int level);
    // bool updateEngineHours(int hours);
    // bool updateEstimatedFuelRange(int range);

    // int getTotalDistanceTravelled();
    // int getBatteryLevel();
    // int getEngineHours();
    // int getEstimatedFuelRange();
    virtual ~database();
};

#endif // DATABASE_H
