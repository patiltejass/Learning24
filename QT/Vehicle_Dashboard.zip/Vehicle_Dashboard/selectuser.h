#ifndef SELECTUSER_H
#define SELECTUSER_H

#include <QDialog>
#include"add_edituser.h"

namespace Ui {
class SelectUser;
}

class SelectUser : public QDialog
{
    Q_OBJECT

public:
    explicit SelectUser(QWidget *parent = nullptr);
    ~SelectUser();

private slots:
    void on_AddUserButton_clicked();

private:
    Ui::SelectUser *ui;
    Add_EditUser *addedit;
};

#endif // SELECTUSER_H
